package com.dbs.ret.restapi.email.test;


import java.util.UUID;

import org.springframework.web.client.RestTemplate;

import com.google.gson.JsonObject;

public class EmailServiceTest {
	private static final String EMAIL_SERVICE_URL = "http://localhost:11201/RET_email_service/sendEmail/";
	private static String FROM = "martin.yj.ma@gmail.com"; 
	private static String TO = "martin.yj.ma@gmail.com"; 
	private static String SUBJECT = "test"; 
	private static String MESSAGE = "test"; 
	
	private void sendEmail() {
		String id = UUID.randomUUID().toString();
		JsonObject jsonObject = new JsonObject();
		jsonObject.addProperty("from", FROM);
		jsonObject.addProperty("to", TO);
		jsonObject.addProperty("subject", SUBJECT);
		jsonObject.addProperty("message", MESSAGE);
		String jsonString = jsonObject.toString();
		System.out.println(jsonString);
		
		RestTemplate restTemplate = new RestTemplate();
		String response = restTemplate.postForObject(EMAIL_SERVICE_URL + id, jsonString, String.class);
		
		System.out.print(response);
	}
	
	public static void main(String arg[]) {
		EmailServiceTest emailServiceTest = new EmailServiceTest();
		emailServiceTest.sendEmail();
	}  

}
