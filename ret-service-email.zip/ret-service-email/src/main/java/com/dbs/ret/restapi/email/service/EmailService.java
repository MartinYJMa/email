package com.dbs.ret.restapi.email.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.File;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Service
public class EmailService {
	private static Logger logger = LogManager.getLogger(EmailService.class);
	

	@Autowired
	private JavaMailSender javaMailSender;
	
	@Value("${json.name.from}")
    private String fromAddress;
	
	@Value("${json.name.to}")
    private String to;
	
	@Value("${json.name.subject}")
    private String subject;
	
	@Value("${json.name.message}")
    private String message;
	
	@Value("${json.name.attachment}")
    private String attachment;
	

	public void sendMailMultipart(String fromAddress, String toEmail, String subject, String message, File file)
			throws MessagingException {
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();

		MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
		helper.setFrom(fromAddress);
		helper.setTo(toEmail);
		helper.setSubject(subject);
		helper.setText(message);

		if (file != null) {
			helper.addAttachment(file.getName(), file);
		}
		javaMailSender.send(mimeMessage);
	}

	public void sendMail(String fromAddress, String toEmail, String subject, String message) throws MessagingException {
		sendMailMultipart(fromAddress, toEmail, subject, message, null);
	}

	public void sendMail(String fromAddress, String toEmail, String subject, String message, File file) throws MessagingException {
		sendMailMultipart(fromAddress, toEmail, subject, message, file);
	}
	
	public void sendMail(String id, String jsonString) throws MessagingException {
		JsonObject jsonObject = new JsonParser().parse(jsonString).getAsJsonObject();
		String from = "";
		try{
			from = jsonObject.get(this.fromAddress).getAsString();
		} catch (Exception e) {
			logger.info("id - " + id + ", 'from' is null");
		}
		String to = "";
		try{
			to= jsonObject.get(this.to).getAsString();
		} catch (Exception e) {
			logger.info("id - " + id + ", 'to' is null");
		} 
		String subject = "";
		try {
			subject = jsonObject.get(this.subject).getAsString();
		} catch (Exception e) {
			logger.info("id - " + id + ", 'subject' is null");
		} 	
		String message = "";
		try{
			message = jsonObject.get(this.message).getAsString();
		} catch (Exception e) {
			logger.info("id - " + id + ", 'message' is null");
		}
		String attachment = "";
		try{
			attachment = jsonObject.get(this.attachment).getAsString();
		} catch (Exception e) {
			logger.info("id - " + id + ", 'attachment' is null");
		}
		if(attachment != null && !attachment .isEmpty())
			sendMail(from, to, subject, message, new File(attachment));
		else
			sendMail(from, to, subject, message);
	}
}
