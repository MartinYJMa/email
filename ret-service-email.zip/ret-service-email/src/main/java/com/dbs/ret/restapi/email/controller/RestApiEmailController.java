package com.dbs.ret.restapi.email.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.ret.restapi.email.service.EmailService;

import javax.mail.MessagingException;

@RestController
@RequestMapping("/")
public class RestApiEmailController {
	private static Logger logger = LogManager.getLogger(RestApiEmailController.class);

	@Autowired
	private EmailService emailService;

	@RequestMapping(value = "/sendEmail/{id}", method = RequestMethod.POST)
	public String sendEmail(@PathVariable("id") String id, @RequestBody String jsonString) {
		logger.info("id: " + id);
		logger.info("jsonString: " + jsonString);
		try {						
			emailService.sendMail(id, jsonString);
			return "Success";
		} catch (MessagingException e) {
			logger.error("id - " + id + ", error: " + e.getMessage());
			return "Fail";
		}
	}
}
